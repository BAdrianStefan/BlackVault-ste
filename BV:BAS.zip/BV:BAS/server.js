const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const app = express();
const db = new sqlite3.Database('users.db');
const port = 3000;

// Middleware pentru date din formulare și JSON
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('.'));

// Creează tabela users dacă nu există
db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    email TEXT,
    tip TEXT DEFAULT 'client'
)`);

// Creează tabela comenzi dacă nu există
db.run(`CREATE TABLE IF NOT EXISTS comenzi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client TEXT,
    produse TEXT,
    livrare TEXT,
    total REAL,
    status TEXT,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)`);

// Test: răspunde la GET /
app.get('/', (req, res) => {
    res.send('Serverul Node.js funcționează!');
});

// Înregistrare utilizator
app.post('/register', (req, res) => {
    const { username, password, email, tip } = req.body;
    if (!username || !password) {
        return res.status(400).send('Username și parola sunt obligatorii!');
    }
    const hash = bcrypt.hashSync(password, 10);
    db.run(
        'INSERT INTO users (username, password, email, tip) VALUES (?, ?, ?, ?)',
        [username, hash, email || '', tip || 'client'],
        function(err) {
            if (err) {
                return res.send('Eroare: utilizatorul există deja!');
            }
            res.send('Cont creat cu succes!');
        }
    );
});

// Autentificare utilizator
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
        if (err || !user) {
            return res.status(401).send('Utilizator sau parolă greșită!');
        }
        if (!bcrypt.compareSync(password, user.password)) {
            return res.status(401).send('Utilizator sau parolă greșită!');
        }
        // Nu trimite parola în răspuns!
        const { password: _, ...userFaraParola } = user;
        res.json(userFaraParola);
    });
});

// Endpoint pentru a primi și salva comenzi (POST)
app.post('/comenzi', (req, res) => {
    const { client, produse, livrare, total, status } = req.body;
    if (!client || !produse) {
        return res.status(400).json({ error: 'Date comandă incomplete!' });
    }
    db.run(
        'INSERT INTO comenzi (client, produse, livrare, total, status) VALUES (?, ?, ?, ?, ?)',
        [
            client,
            JSON.stringify(produse),
            JSON.stringify(livrare),
            total || 0,
            status || 'noua'
        ],
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Eroare la salvarea comenzii!' });
            }
            res.json({ status: 'Comanda a fost salvată!', id: this.lastID });
        }
    );
});

// Endpoint pentru a vedea toate comenzile (GET)
app.get('/comenzi', (req, res) => {
    db.all('SELECT * FROM comenzi ORDER BY data DESC', [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: 'Eroare la citirea comenzilor!' });
        }
        // Parsează produsele și livrarea din JSON
        rows.forEach(row => {
            row.produse = JSON.parse(row.produse);
            row.livrare = JSON.parse(row.livrare);
        });
        res.json(rows);
    });
});

// Endpoint pentru a vedea toți utilizatorii (GET)
app.get('/users', (req, res) => {
    db.all('SELECT id, username, email, tip FROM users', [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: 'Eroare la citirea utilizatorilor!' });
        }
        res.json(rows);
    });
});

// Endpoint pentru a șterge o comandă după id (DELETE)
app.delete('/comenzi/:id', (req, res) => {
    db.run('DELETE FROM comenzi WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            return res.status(500).json({ error: 'Eroare la ștergerea comenzii!' });
        }
        res.json({ status: 'Comanda a fost ștearsă!' });
    });
});

// Endpoint pentru a șterge un utilizator după id (DELETE)
app.delete('/users/:id', (req, res) => {
    db.run('DELETE FROM users WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            return res.status(500).json({ error: 'Eroare la ștergerea utilizatorului!' });
        }
        res.json({ status: 'Utilizatorul a fost șters!' });
    });
});

app.listen(port, () => {
    console.log(`Serverul rulează la http://localhost:${port}`);
});