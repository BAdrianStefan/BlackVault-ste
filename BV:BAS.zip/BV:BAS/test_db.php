<?php
$host = "localhost";
$user = "blackvau_admin"; // userul MySQL, nu cel de cPanel!
$pass = "parola_userului_mysql"; // parola setată pentru userul MySQL
$db   = "blackvau_Db"; // exact cum apare în cPanel
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Eroare conectare: " . $conn->connect_error);
}
echo "Conexiune reușită!";
?>